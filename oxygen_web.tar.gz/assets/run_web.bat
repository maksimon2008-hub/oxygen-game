
@echo off
cd /d "%~dp0\.."

title OXYGEN WEB BUILD

set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

echo Starting OXYGEN WEB...
py -m pygbag --PYBUILD 3.14 oxygen_web

pause
